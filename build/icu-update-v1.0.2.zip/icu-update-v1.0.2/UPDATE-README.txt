ICU Control Station - Offline update  v1.0.1 -> v1.0.2
======================================================

WHAT CHANGED
  - Application title: "Experia"  ->  "JDHC"
  - Ajloun hospital code unified as AIGH (the hospital tab and the
    patient card site label used to show AISH while the patient ID
    said AIGH-ICU7)

NO INTERNET NEEDED
  Dependencies did not change in this release. Only the obfuscated
  backend .js files and the static frontend build are replaced.
  node_modules, .env and certs\ on the client device are NOT touched,
  and no npm install is required.


OPTION A - automatic (recommended)
----------------------------------
  1. Copy this folder to the client device (USB / RDP copy).
  2. Open PowerShell or CMD as Administrator.
  3. Run, passing the install folder:

       .\update-to-v1.0.2.bat "C:\icu-control-station-v1.0.0"

     (Without an argument it defaults to C:\icu-control-station-v1.0.0)

  The script stops pm2, backs up the current backend src and
  frontend-build into a backup-YYYYMMDD-HHMMSS folder, copies the new
  files, and restarts pm2.


OPTION B - manual
-----------------
  set $T = "C:\icu-control-station-v1.0.0"

  1. Stop the services:
       pm2 stop icu-bridge icu-consumer

  2. Back up (keep the .bak convention you used last time):
       Rename-Item "$T\backend-obfuscated\src" "src.bak"
       Rename-Item "$T\frontend-build"         "frontend-build.v1.0.1.bak"

  3. Copy the new files:
       Copy-Item ".\backend-obfuscated\src" "$T\backend-obfuscated\" -Recurse
       Copy-Item ".\frontend-build"         "$T\" -Recurse

     IMPORTANT: copy only the src folder into backend-obfuscated.
     Do NOT delete or replace backend-obfuscated\node_modules,
     backend-obfuscated\.env or backend-obfuscated\certs.

  4. Restart:
       pm2 restart icu-bridge icu-consumer
       pm2 save
       pm2 status

  5. Open http://localhost:3000 and press CTRL+F5 (hard refresh).


VERIFY
  - Browser tab and header read  JDHC
  - Hospital tabs read  TGH / MNGH / RGH / AIGH / MFG
  - A patient with device ID AIGH-ICU7 shows "AIGH - Ajloun"
  - pm2 status shows icu-bridge and icu-consumer online
  - pm2 logs icu-bridge --lines 50   (no startup errors)


ROLLBACK
  1. pm2 stop icu-bridge icu-consumer
  2. Copy the files back from the backup-YYYYMMDD-HHMMSS folder
     (or restore the .bak folders).
  3. pm2 restart icu-bridge icu-consumer
