@echo off
REM ============================================================
REM  ICU Control Station - Offline update to v1.0.2
REM  Usage:  update-to-v1.0.2.bat  [install folder]
REM  Default install folder: C:\icu-control-station-v1.0.0
REM  No internet required - node_modules are NOT touched.
REM ============================================================
setlocal EnableDelayedExpansion

set "TARGET=%~1"
if "%TARGET%"=="" set "TARGET=C:\icu-control-station-v1.0.0"
set "SRC=%~dp0"

echo.
echo ================================================
echo   ICU Control Station - Update to v1.0.2
echo ================================================
echo   Source : %SRC%
echo   Target : %TARGET%
echo.

if not exist "%TARGET%\backend-obfuscated\src" (
    echo ERROR: "%TARGET%\backend-obfuscated\src" not found.
    echo Pass the correct install folder, e.g.:
    echo     update-to-v1.0.2.bat "C:\icu-control-station-v1.0.0"
    pause
    exit /b 1
)

REM ---- timestamp for the backup folder ----
for /f "tokens=2 delims==" %%a in ('wmic OS Get localdatetime /value ^| find "="') do set "DT=%%a"
set "STAMP=%DT:~0,8%-%DT:~8,6%"
set "BACKUP=%TARGET%\backup-%STAMP%"

echo [1/5] Stopping services...
pm2 stop icu-bridge icu-consumer >nul 2>&1

echo [2/5] Backing up current version to:
echo       %BACKUP%
mkdir "%BACKUP%" >nul 2>&1
xcopy "%TARGET%\backend-obfuscated\src" "%BACKUP%\backend-src\" /E /I /Y /Q >nul
xcopy "%TARGET%\frontend-build"         "%BACKUP%\frontend-build\" /E /I /Y /Q >nul

echo [3/5] Updating backend (obfuscated sources only)...
copy /Y "%SRC%backend-obfuscated\src\*.js" "%TARGET%\backend-obfuscated\src\" >nul
if errorlevel 1 goto :failed

echo [4/5] Updating frontend build...
if exist "%TARGET%\frontend-build\assets" rmdir /S /Q "%TARGET%\frontend-build\assets"
xcopy "%SRC%frontend-build" "%TARGET%\frontend-build\" /E /I /Y /Q >nul
if errorlevel 1 goto :failed

echo [5/5] Restarting services...
pm2 restart icu-bridge icu-consumer
pm2 save >nul 2>&1

echo.
echo ================================================
echo   Update to v1.0.2 complete
echo ================================================
echo.
echo   Backup kept at: %BACKUP%
echo.
echo   Now open the dashboard and press CTRL+F5:
echo     http://localhost:3000
echo.
echo   You should see:  JDHC   and the  AIGH  hospital tab.
echo.
pm2 status
pause
exit /b 0

:failed
echo.
echo ERROR: update failed. Restore from: %BACKUP%
pause
exit /b 1
